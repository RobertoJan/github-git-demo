<!-- copy over the student README in here, when you finish the challenge
so you can give the solution as a package to the students -->