# Santas Little Helpers
### `Morning challenge | JavaScript - Promises`

## Learning Objectives
- how do Promises work?
- making a Promise, thening a Promise
- catching errors in Promises
- executing Promises in parallel

## Instructions
- Follow the TODO's and comments in script.js