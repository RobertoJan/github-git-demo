# Higher Order Functions
### `Morning challenge | javascript`

## Learning objectives
- what are higher order functions?
- using some common higher order functions
- understanding how higher order functions work under the hood

## Instructions
- follow the exercises by number and write your code by replacing the TODO comments