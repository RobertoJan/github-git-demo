# HTTP Fundamentals
### `Morning challenge | JavaScript - HTTP Fundamentals`

## Learning Objectives
- Learn about the HTTP Fundamentals
- Learn about making GET requests to different API's

## Instructions
<!-- write walkthrough notes and setup notes here for the student. -->