getStarships = () => {
  // Place GET Request here
};

getStarships();

postShip = (results, i) => {
  let starwarsContainer = document.querySelector(".starwars-container");

  let ship = document.createElement("p");
  // ship.innerHTML = ** set the innerHTML to the starship name here
  starwarsContainer.appendChild(ship);
};

