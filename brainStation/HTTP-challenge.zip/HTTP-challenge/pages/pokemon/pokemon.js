getFirePokemon = () => {
  // Place GET Request here
};

getFirePokemon();

postPokemon = (results, i) => {
  let pokemonContainer = document.querySelector(".pokemon-container");

  let pokemon = document.createElement("p");
  // pokemon.innerHTML = set innerHTML to the pokemon name here
  pokemonContainer.appendChild(pokemon);
};
